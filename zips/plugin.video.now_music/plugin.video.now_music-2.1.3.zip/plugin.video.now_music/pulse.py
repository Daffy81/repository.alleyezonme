# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------
if 64 - 64: i11iIiiIii
import os
import sys
import plugintools
import xbmc , xbmcaddon
from addon . common . addon import Addon
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = 'plugin.video.now_music'
oo = Addon ( o0OO00 , sys . argv )
i1iII1IiiIiI1 = xbmcaddon . Addon ( id = o0OO00 )
iIiiiI1IiI1I1 = i1iII1IiiIiI1 . getAddonInfo ( 'icon' )
if 87 - 87: OoOoOO00
xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
if 27 - 27: OOOo0 / Oo - Ooo00oOo00o . I1IiI
o0OOO = "PLhXCO9UQq4zpTUQlXd8ZT_xOdEDu7dTqv"
iIiiiI = "PLhXCO9UQq4zosNDc-5I_KtJJoaV066G-W"
Iii1ii1II11i = "PLhXCO9UQq4zrHCS5_aR6-bRJ3StFc4tA4"
iI111iI = "PLhXCO9UQq4zp6J80nhPKO3G1Bvr-CGD6v"
IiII = "PLhXCO9UQq4zoj1vkc2fSXgFiSVtsZayHv"
iI1Ii11111iIi = "PLhXCO9UQq4zo-hnosy9wpsDNeiO-PrSJR"
i1i1II = "PLhXCO9UQq4zrEMGS14CG5Nb5ZnZc0kdUn"
O0oo0OO0 = "PLhXCO9UQq4zpe4iFya6vg2OHEMksOR_VE"
I1i1iiI1 = "PLhXCO9UQq4zpzGN0ESjO3e6sNdeGwOsE4"
iiIIIII1i1iI = "PLhXCO9UQq4zpIXWn6oNREwVwCgs040VHF"
o0oO0 = "PLhXCO9UQq4zrOT31ZKShnJzvYS5np_DZs"
oo00 = "PLhXCO9UQq4zqdU5jlLorN7J7cLSHot94b"
o00 = "PLhXCO9UQq4zpSJrLac2SqeXyhdXp9LKUe"
Oo0oO0ooo = "PLhXCO9UQq4zoUG9jmR5wxR0bBSwTPiPK7"
o0oOoO00o = "PLhXCO9UQq4zrKoCftfe7FoHBZr9LSWtFH"
i1 = "PLhXCO9UQq4zqZNJfDmSziiDHdE4U42WIw"
oOOoo00O0O = "PLhXCO9UQq4zocy1cp19Adq33UqDmhBcZ6"
i1111 = "PLhXCO9UQq4zr0LqahXzmi4E_ns_6mpZz2"
i11 = "PLhXCO9UQq4zpHFqKi-ImkvpHBdSnJ4rlj"
I11 = "PLhXCO9UQq4zoyD3PRgUGE_CpeGH64uYbl"
Oo0o0000o0o0 = "PLhXCO9UQq4zqM30AfNKs5vifuY3F5AjoS"
oOo0oooo00o = "PLhXCO9UQq4zpIppJgk8eO6q6rLj5cd66j"
oO0o0o0ooO0oO = "PLhXCO9UQq4zozB-V6s3iOYbKlBHw2HiRn"
oo0o0O00 = "PLhXCO9UQq4zqitcxqUgf3ExVLnYgrVz9O"
oO = "PLhXCO9UQq4zrww3CobDJYU5wPXAeW6Q7v"
i1iiIIiiI111 = "PLhXCO9UQq4zrpdTnC_FKSuIWVMuHgAg9_"
oooOOOOO = "PLhXCO9UQq4zo_PnPlNHC9O9s5nzTwi843"
i1iiIII111ii = "PLhXCO9UQq4zqCR8BpGKByzNAShUUKQfgs"
i1iIIi1 = "PLhXCO9UQq4zqpG5BjqH7AHKP9l_PYohC3"
ii11iIi1I = "PLhXCO9UQq4zo9VKs1rqfUzJcmBRI-1hbO"
iI111I11I1I1 = "PLhXCO9UQq4zomYbmCLbvelV6iyNqeZHy8"
OOooO0OOoo = "PLhXCO9UQq4zqHilh_rHAmcEgHr5sVWkhp"
iIii1 = "PLhXCO9UQq4zrlOfZHCdLPv1qPI8vWzcZq"
oOOoO0 = "PLhXCO9UQq4zoG_VSWsi46pE2feeWftVmy"
O0OoO000O0OO = "PLhXCO9UQq4zoVMCVQFedvpQyT9mc_ou_I"
iiI1IiI = "PLhXCO9UQq4zq2UytFtE2Ztv2aEEoHLL3Y"
II = "PLhXCO9UQq4zpDEjhD4rFuwBi6UbRUD8XT"
ooOoOoo0O = "PLhXCO9UQq4zoEsVoosoBwuYHQTQcJGJl0"
OooO0 = "PLhXCO9UQq4zo9GUw9avm2ADPtYo3mG7hz"
II11iiii1Ii = "PLhXCO9UQq4zqSlwET-Laz-0E7hBcvz-AS"
OO0o = "PLhXCO9UQq4zoPy-QPY1wRc-tRAOmlJ2Sr"
Ooo = "PLhXCO9UQq4zpArvGdKY_L7BGShjmbJEsl"
O0o0Oo = "PLhXCO9UQq4zoDzjd-0kdiNOeFJ8kMr2xU"
Oo00OOOOO = "PLhXCO9UQq4zoqQAjUb5lLa9sDQA4W-X89"
O0O = "PLhXCO9UQq4zoxUnwMREME7NGfVVKzV_L9"
O00o0OO = "PLhXCO9UQq4zrpQvSHwSXDfVSUQrGv8FrI"
I11i1 = "PLhXCO9UQq4zoERELJNVo2QXqXGja40mEX"
iIi1ii1I1 = "PLhXCO9UQq4zr-XHi-tG65bwoU4gmLVQ92"
o0 = "PLhXCO9UQq4zpaxhOWon7euVBMhneHXEIS"
I11II1i = "PLhXCO9UQq4zqpjoiiryt4nSXF-rjVxJch"
IIIII = "PLhXCO9UQq4zpLu1b1WuRCKIE_McG-LCXa"
ooooooO0oo = "PLhXCO9UQq4zpQSX5x12cUqu22vW8pOnPB"
IIiiiiiiIi1I1 = "PLhXCO9UQq4zqsxurpA-CD_E_cjxWDISl4"
I1IIIii = "PLhXCO9UQq4zrz9TZfd5P1J5kfX3lgvh8v"
oOoOooOo0o0 = "PLhXCO9UQq4zqE_xp3T_YSVhHa2mJHDY8k"
OOOO = "PLhXCO9UQq4zpHG3sFm7hTiC2CPrPLst2m"
OOO00 = "PLhXCO9UQq4zqX2N4tXNpQcB_6yz1TQKIu"
iiiiiIIii = "PLhXCO9UQq4zrPZQ295Fmrcac3zZ28wgsF"
O000OO0 = "PLhXCO9UQq4zpJ1Hj2gQHvtxhK4IY3cFlT"
I11iii1Ii = "PLhXCO9UQq4zoun5LnVvD5RXHbO9aZoEd6"
I1IIiiIiii = "PLhXCO9UQq4zrgxrIMc3Ts0K5jrFHcwbEa"
O000oo0O = "PLhXCO9UQq4zpMpQnfl8icrRrcwam9QBbx"
OOOOi11i1 = "PLhXCO9UQq4zolAEJPm9tZii4PL7v-K-Bs"
IIIii1II1II = "PLhXCO9UQq4zpTV3BJwCFr1HH6Ng8E8jGc"
i1I1iI = "PLhXCO9UQq4zp2ucyUaBZkaxGsEd4e5Whi"
oo0OooOOo0 = "PLhXCO9UQq4zqhmkDf0K17hxsJgevqLfOA"
o0O = "PLhXCO9UQq4zo52cMT3qCf0hthSnIm-Q6I"
O00oO = "PLhXCO9UQq4zrYMch6hCIo41YH63XbsRAx"
I11i1I1I = "PLhXCO9UQq4zr-VIwDoD5mYkAZd9VGrDyj"
oO0Oo = "PLhXCO9UQq4zr-VIwDoD5mYkAZd9VGrDyj"
oOOoo0Oo = "PLhXCO9UQq4zpID8mZ6Ta8AQPxPF4urC9Q"
o00OO00OoO = "PLhXCO9UQq4zr2BKXfjkIICqINzBdtPDin"
OOOO0OOoO0O0 = "PLhXCO9UQq4zqveE99Y7pel-1TzvkdTQrD"
O0Oo000ooO00 = "PLhXCO9UQq4zpHVO2vgvn0t81J3TKaAXRw"
oO0 = "PLhXCO9UQq4zpOY4NMYa29wzz-Bg60h433"
Ii1iIiII1ii1 = "PLhXCO9UQq4zryTUlIT6zMCpDnfAfBYKXH"
ooOooo000oOO = "PLhXCO9UQq4zqH-f97-x6wX3cvUhXNvEjr"
Oo0oOOo = "PLhXCO9UQq4zrQF98HQELPV_iuTNMZitUo"
Oo0OoO00oOO0o = "PLhXCO9UQq4zpkoNcM38eEV0qBDDLz5EJk"
OOO00O = "PLhXCO9UQq4zqPaf2NgHHTaNvxq74JmqLm"
OOoOO0oo0ooO = "PLhXCO9UQq4zpvQW-dIkN_A7rLnbq0WVsN"
O0o0O00Oo0o0 = "PLhXCO9UQq4zq647XB3xRnXRqftKtBD5Jj"
O00O0oOO00O00 = "PLhXCO9UQq4zrSuhXejoRc09hlLKONLmfj"
i1Oo00 = "PLhXCO9UQq4zpXpoUuM3CnXTvtjFljA1EX"
i1i = "PLhXCO9UQq4zqGsPWpYiXLq6F4UOFbQO53"
iiI111I1iIiI = "PLhXCO9UQq4zpbqfafnYzvMTBH1RG2EwTw"
IIIi1I1IIii1II = "PLhXCO9UQq4zoADgOFRIyqkrEIunLzlwzv"
O0ii1ii1ii = "PLhXCO9UQq4zrVa_aTe9wP8x5FVf7Sixb3"
oooooOoo0ooo = "PLhXCO9UQq4zpRPIvu59_j4C-BwLKATbAc"
I1I1IiI1 = "PLhXCO9UQq4zrHZe7rxpl4m_esn5FwNKk3"
III1iII1I1ii = "PLhXCO9UQq4zp64VMqY05rCwZateeeZ-rp"
oOOo0 = "PLhXCO9UQq4zrcNtW3paR0ywGDhPTRq788"
oo00O00oO = "PLhXCO9UQq4zqi5svFuiBiK6grQozMy8AS"
iIiIIIi = "PLhXCO9UQq4zrBdLE9xsIrl-Wkust_ytg-"
ooo00OOOooO = "PLhXCO9UQq4zohQiwZP_I5Mht4zssrqsTC"
O00OOOoOoo0O = "PLhXCO9UQq4zoBXNlUcJAKvq6zEtSyf9Xi"
O000OOo00oo = "PLhXCO9UQq4zpz0uOiu3zRfIEDCV9On7yY"
oo0OOo = "PLhXCO9UQq4zqP89arDyDrMihOnrtzaQWZ"
ooOOO00Ooo = "PLhXCO9UQq4zr95rMscDN0vhNwo6Olz2wx"
IiIIIi1iIi = "PLhXCO9UQq4zo4PCCkLAlXCSwTCG_ylLG4"
ooOOoooooo = "PLhXCO9UQq4zrEDnNduDRxd8vTxW6KjvRj"
II1I = "PLhXCO9UQq4zqHx_V06FJvixiryW7bWJFi"
O0i1II1Iiii1I11 = "PLhXCO9UQq4zrwJrzJ_FkcXpXpri78cAjz"
IIII = "PLhXCO9UQq4zrNhvfQ2q-ZGqnIoM3va3jl"
iiIiI = "PLhXCO9UQq4zrjtA13E2g06eaXmdiaCuCZ"
o00oooO0Oo = "PLhXCO9UQq4zqgbyayHDzK0fCUAePlb6lh"
o0O0OOO0Ooo = "PLhXCO9UQq4zoaLmSOmzm8Q-wb7v1VQV5k"
iiIiII1 = "PLhXCO9UQq4zr_rO8dCGOSWjJ9dFT1kTkK"
OOO00O0O = "PLhXCO9UQq4zqCE4HASBbjq0QvQjgBpZjL"
iii = "PLhXCO9UQq4zrBmEeKb-QxGnKi2UYrr8Jw"
oOooOOOoOo = "PLhXCO9UQq4zoaLtB_rMP-eYlgV2DXLZof"
i1Iii1i1I = "PLhXCO9UQq4zqSPx9l-EUMsdOjQlkBAFWC"
OOoO00 = "PLhXCO9UQq4zroQ98yFNfKCUThjpJ0NJpg"
IiI111111IIII = "PLhXCO9UQq4zrBY7O2K64ZEoG2aLwHhrWe"
i1Ii = "PLhXCO9UQq4zqSd2OnkoIHWNfJ8QLHow3Z"
ii111iI1iIi1 = "PLhXCO9UQq4zrl92rsHFVsxoscfUuE_SDP"
OOO = "PLhXCO9UQq4zqMVEVrdS9PhtaDFp74-nIu"
oo0OOo0 = "PLhXCO9UQq4zoCzYMDYJLZgSGtDWmWUsGq"
I11IiI = "PLhXCO9UQq4zo5X7V43pTX6lJHSONk2dsL"
O0ooO0Oo00o = "PLhXCO9UQq4zpPUzzqsrBLaqf4vzQhPZ1l"
ooO0oOOooOo0 = "PLhXCO9UQq4zrixOrTzc8dFEggSA12Eu3w"
i1I1ii11i1Iii = "PLhXCO9UQq4zpJIoi7F555WZOOQEiasYhx"
I1IiiiiI = "PLhXCO9UQq4zqUMDTzaAbbXXg3mUiCALlr"
o0OIiII = "PLhXCO9UQq4zqIrti0fs9SGD6UbCz6-uCM"
ii1iII1II = "PLhXCO9UQq4zrvmhWz2evipfCph-qYeLNj"
Iii1I1I11iiI1 = "PLhXCO9UQq4zpWh2A03lu7Ilz_nhcROQRY"
I1I1i1I = "PLhXCO9UQq4zq7ug-SyFxS2exJybSiv4sw"
ii1I = "PLhXCO9UQq4zrm1rV81VTZcqhI0NXJ-Fpl"
O0oO0 = "PLhXCO9UQq4zp1fGJ-vxIfI55KEhSkirrX"
oO0O0OO0O = "PLhXCO9UQq4zqYVsLhQt6lQvK4xTRMJprA"
OO = "PLhXCO9UQq4zrtKJCVk0iALxcwMsCiJ2TP"
OoOoO = "PLhXCO9UQq4zqL-uPLw717fE2DK26yS3yX"
Ii1I1i = "PLhXCO9UQq4zoQqKhzC4PFFOvXmDxcyx8k"
OOI1iI1ii1II = "PLhXCO9UQq4zpyggDlR13uE6fRM-1aNI3S"
O0O0OOOOoo = "PLhXCO9UQq4zr-nXuvmrVKJAyiLTUee5P9"
oOooO0 = "PLhXCO9UQq4zpOURmY878xY3cMgRmSc-Ar"
Ii1I1Ii = "PLhXCO9UQq4zrsYRXCne-WWvS3UyypQhgo"
OOoO0 = "PLhXCO9UQq4zo-8umQbOCmCtbo8_eptRG1"
OO0Oooo0oOO0O = "PLhXCO9UQq4zqGAVwUMwgUnfkBd7rpLER9"
o00O0 = "PLhXCO9UQq4zo_GMFSjjrusmMkunHv8JwW"
oOO0O00Oo0O0o = "PLhXCO9UQq4zpu-R1n-QMF0iu13xoyrjWE"
ii1 = "PLhXCO9UQq4zrW1Aj099Nq3oyqTn_UJ6cq"
I1iIIiiIIi1i = "PLhXCO9UQq4zoIJY4qa1UA_WQWuwS-y2bc"
O0O0ooOOO = "PLhXCO9UQq4zqleg7Y6_83kZFgCl-my85S"
oOOo0O00o = "PLhXCO9UQq4zqHtU1o6EkD9EOCb1K4-Y-B"
iIiIi11 = "PLhXCO9UQq4zrqj7QArQiaSdg6llcKQ3is"
OOOiiiiI = "PLhXCO9UQq4zrcj--wOeIZoX3p9EHtrg62"
oooOo0OOOoo0 = "PLhXCO9UQq4zp6FDuhZEeHCk68sW15TXID"
OOoO = "PLhXCO9UQq4zpKXAvjL7AvS2zDamssUNx2"
OO0O000 = "PLhXCO9UQq4zpPO7TZRME_TGG_SZZPEo6y"
iiIiI1i1 = "PLhXCO9UQq4zqJU3ONSlpLUksFk3uJCa1w"
oO0O00oOOoooO = "PLhXCO9UQq4zoWcnbyo2P92yaFSPSI7jL-"
IiIi11iI = "PLhXCO9UQq4zqx0PWzoJzac_MVHmU8Ds2z"
Oo0O00O000 = "PLhXCO9UQq4zpKrb65zNsPdCFdqbF3iOWd"
i11I1IiII1i1i = "PLhXCO9UQq4zrDePvJyEH4QhAdkgGtW04j"
ooI1111i = "PLhXCO9UQq4zpcqQCYi0tncwRELyc_ZpOg"
iIIii = "PLhXCO9UQq4zp4agrmnCik9RtBTl7zVE4X"
o00O0O = "PLhXCO9UQq4zpmG1RXB6p52sD7v5WyoUUP"
ii1iii1i = "PLhXCO9UQq4zpfgX79bPGyKOjrqn8Tu60a"
Iii1I1111ii = "PLhXCO9UQq4zpLYS1Uw51PHCpkFwYCa8gb"
ooOoO00 = "PLhXCO9UQq4zpKaTxxWK8utWl8qY3OGM4z"
Ii1IIiI1i = "PLhXCO9UQq4zp_PrJQWT4Ikptppm4V6rSs"
o0O00Oo0 = "PLhXCO9UQq4zpVD6AI98LxQiREjiv8-hBT"
IiII111i1i11 = "PLhXCO9UQq4zqopHcDkBO0MMHCEXui5QsI"
i111iIi1i1II1 = "PLhXCO9UQq4zruSRLSjmnL0h36CZ8srRNE"
oooO = "PLhXCO9UQq4zq2xkDQlUeAERG_ToSJo66Z"
i1I1i111Ii = "PLhXCO9UQq4zrGzj0NVHN8MZFdxYNwezO5"
ooo = "PLhXCO9UQq4zprYxE4z7gVF5QhravDBjHC"
i1i1iI1iiiI = "PLhXCO9UQq4zpJM7_sfWVgHoHkh4VbS8Zl"
Ooo0oOooo0 = "PLhXCO9UQq4zpFFP-UZTM7Cbs79K9_31i4"
oOOOoo00 = "PLhXCO9UQq4zpAmPQkOdpYeGEyYU4uGl_H"
iiIiIIIiiI = "PLhXCO9UQq4zrZ6-J0xmz1vblWw3r5gVyJ"
iiI1IIIi = "PLhXCO9UQq4zppfOiZY44FdFJNtYe84nLw"
II11IiIi11 = "PLhXCO9UQq4zrZP9FdTnr_3OL1R2N4V9Ii"
IIOOO0O00O0OOOO = "PLhXCO9UQq4zq1WrbNzyDZ673UTkWRjYj_"
I1iiii1I = "PLhXCO9UQq4zrpv9ABw9t0ezHi6gKi0N4E"
OOo0 = "PLhXCO9UQq4zqG5vXwRfE-LxoU-JpqvPN4"
oO00ooooO0o = "PLhXCO9UQq4zqZGO9GFy63Q41jf3eqlnIf"
oo0o = "PLhXCO9UQq4zqE2SmMqDDLmskOik4ne0sY"
o0oO0oooOoo = "PLhXCO9UQq4zpbweLXGXAOQKewcwJ_W80H"
I1III1111iIi = "PLhXCO9UQq4zoKQ84TmeuNWhSDb1YuYfnt"
I1i111I = "PLhXCO9UQq4zrmpxTd_CbeMqU6_Hc_NZvx"
OooOo0oo0O0o00O = "PLhXCO9UQq4zpOq9dElwF2_Ri2my_wsMYK"
I1i11 = "PLhXCO9UQq4zqYxaFFsiMcoZercrJ42GUA"
IiIi1I1 = "PLhXCO9UQq4zooLzQuxJSzYrfBB0NWHgAv"
IiIIi1 = "PLhXCO9UQq4zo9lFdjgdQjWeP_bi_i8cwe"
IIIIiii1IIii = "PLhXCO9UQq4zofX58GYRXXYozK3CN4nLQz"
II1i11I = "PLhXCO9UQq4zp6sogClTx_ZyzTFsc-sTww"
ii1I1IIii11 = "PLhXCO9UQq4zqMsYRAEL0zPoz_OgHxVQUr"
O0o0oO = "PLhXCO9UQq4zo2sIVNyF5mh9pqE8A-Vz3P"
IIIIiIiIi1 = "PLhXCO9UQq4zpa_n2j0Z1nwFwiUbHcaHys"
I11iiiiI1i = "PLhXCO9UQq4zrA2Vd_5B8vFjMFGQSyjuQO"
iI1i11 = "PLhXCO9UQq4zqfI4pBUXztmXf_0y0z3FHe"
OoOOoooOO0O = "PLhXCO9UQq4zqI5vmTbUyaBYWCP_ij4ZAa"
ooo00Ooo = "PLhXCO9UQq4zoRxxzkg5dePfpNp7snc_7p"
Oo0o0O00 = "PLhXCO9UQq4zpCAcRfaG4dnL8CHsc5Owu6"
ii1I1i11 = "PLhXCO9UQq4zrlREjBn4B4bpGGQgNSYDwV"
OOo0O0oo0OO0O = "PLhXCO9UQq4zqml54qjdGnZfJvwJUXOl5d"
OO0 = "PLhXCO9UQq4zqcTHOjit6fEWzvnt4dzBrO"
o0Oooo = "PLhXCO9UQq4zptYTWDz2sGEDsm0PQmyBTW"
iiI = "PLhXCO9UQq4zrRbylElKgk74JZiUMUb0mB"
oOIIiIi = "PLhXCO9UQq4zoOSolxtp5DLFzVd1slBGBY"
OOoOooOoOOOoo = "PLhXCO9UQq4zqwp2zPGGu-SQnKlAfswMQs"
Iiii1iI1i = "PLhXCO9UQq4zqBZHQZX4Z9Dvor5qWEkc6E"
I1ii1ii11i1I = "PLhXCO9UQq4zo1rF_zm_nZK0kVcn80M8pa"
o0OoOO = "PLhXCO9UQq4zrZbYYH9orR1pTZ5UG49zFg"
O0O0Oo00 = "PLhXCO9UQq4zo5DaXOsoU8ekS4QmtdoAk6"
oOoO00o = "PLhXCO9UQq4zrbw2wVz_pRKD2064xVy52H"
oO00O0 = "PLhXCO9UQq4zr3Gb-0OfMuVxiCMN5wkRav"
IIi1IIIi = "PLhXCO9UQq4zrhdrb_nCZL5f8KqlceuQde"
O00Ooo = "PLhXCO9UQq4zoZSBvULuLLTQH1rBi1QDIx"
OOOO0OOO = "PLhXCO9UQq4zo8XuB7wsCLrHKiL_H_B2KQ"
i1i1ii = "PLhXCO9UQq4zqNaWL0dFGvpGjKahoWlMPf"
iII1ii1 = "PLhXCO9UQq4zowesn5wymeWfbzqxJDmpIQ"
I1i1iiiI1 = "PLhXCO9UQq4zoW5rXYUQCv32y6IZnnEEgk"
iIIi = "PLhXCO9UQq4zrL3GBy0ku497HC97jpcjno"
oO0o00oo0 = "PLhXCO9UQq4zqe42hMjmPGGV30dUvfy5ZI"
ii1IIII = "PLhXCO9UQq4zq-Q2JQwW2ZYntw48pOovEY"
oO00oOooooo0 = "PLhXCO9UQq4zpEtulWw574o_y5v2JEsNEj"
oOo = "PLhXCO9UQq4zphl59rV3QyoGsANqDUbZOc"
O0OOooOoO = "PLhXCO9UQq4zpIgxvJg-CI2EzSXiA_qLdo"
i1II1I1Iii1 = "PLhXCO9UQq4zp-Qd_MWaUCmQXyNs3Y7N8R"
iiI11Iii = "PLhXCO9UQq4zqBl17fZNxQfdmPBTtKT4a_"
O0o0O0 = "PLhXCO9UQq4zpTpTDPbZ-iIlFVcaqSzF-O"
Ii1II1I11i1 = "PLhXCO9UQq4zrHseRu5w1OELWBNbp4IS_s"
oOoooooOoO = "PLhXCO9UQq4zoyksUvZbvjMYlSz2B9eDwn"
Ii111 = "PLhXCO9UQq4zosccGMdyCinFpdHvSE9Kvu"
I111i1i1111 = "PLhXCO9UQq4zrIK5Wi1BUF8MpiRxAdpYE5"
IIII1 = "PLhXCO9UQq4zpbPukW3gh3YAL2Yk3p04yc"
I1I1i = "PLhXCO9UQq4zpRqgJrZrPNuE4W-h62RKNP"
I1IIIiIiIi = "PLhXCO9UQq4zrpboyTxddvzTIYQwsuK6te"
IIIII1 = "PLhXCO9UQq4zr1s3_4pkpw7Fms2Oq8Z7tn"
iIi1Ii1i1iI = "PLhXCO9UQq4zpS2rBuOchNScXa2xRrQtSH"
IIiI1 = "PLhXCO9UQq4zrpPKcLdd1f-Sbpo6YFNrXn"
i1iI1 = "PLhXCO9UQq4zqacK5gziO0FX4GWBTI4tVp"
ii1I1IiiI1ii1i = "PLhXCO9UQq4zpxs9qVwJkilFd3RDuu_FLI"
O0o = "PLhXCO9UQq4zo1uKFNr1sT_PmmNhCqTIWM"
oO0OoO00o = "PLhXCO9UQq4zqBq6mmsYVf0grqgJGEQ0A7"
II1iiiiII = "PLhXCO9UQq4zqM_farq5RrXIpd5zTx1Kdt"
if 61 - 61: OOO0o % OoOOO00 . II1111ii * iIIII1iIIii / oOOO00o000o
if 9 - 9: o0o00o0O00 + I11i1iIiIIIIIii / OOo0ii11I1
def oO0oo ( ) :
 plugintools . log ( "docu.run" )
 if 38 - 38: I1iIi1iIiiIiI * oo00ooOoO00 + i11iIiiIii * iIIII1iIIii
 if 85 - 85: OOO0o . I1IiI / oo00ooOoO00 . O0 % I1iIi1iIiiIiI
 OO0ooo0oOO = plugintools . get_params ( )
 if 97 - 97: OOOo0 / I11i1iIiIIIIIii
 if OO0ooo0oOO . get ( "action" ) is None :
  Oooo0 ( OO0ooo0oOO )
 else :
  oOO = OO0ooo0oOO . get ( "action" )
  exec oOO + "(params)"
  if 54 - 54: OOOo0 / iIii1I11I1II1 / iIIII1iIIii . iIIII1iIIii % I11i1iIiIIIIIii . OOOo0
 plugintools . close_item_list ( )
 if 10 - 10: OOO0o + iIIII1iIIii
 if 27 - 27: Ooo00oOo00o . oOOO00o000o + I1IiI / iIii1I11I1II1 % I11i1iIiIIIIIii . oo00ooOoO00
def Oooo0 ( params ) :
 plugintools . log ( "docu.main_list " + repr ( params ) )
 if 14 - 14: II1111ii + OoOOO00 - I11i1iIiIIIIIii / O0 . I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 98" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOoooooOoO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/10/FINAL-now98ski1300dpi-200x200.png" ,
 folder = True )
 if 45 - 45: I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 97" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/06/now97_RESORT_300dpi_layers-200x200.jpg" ,
 folder = True )
 if 83 - 83: I1IiI . OoooooooOO
 plugintools . add_item (

 title = "Now 96" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1I1i11 + "/" ,
 thumbnail = "https://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/04/now96_inks_CYMK_300dpi-1024x1024-200x200.jpg" ,
 folder = True )
 if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / OOo0ii11I1 / i11iIiiIii
 plugintools . add_item (

 title = "Now 95" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii1I1i + "/" ,
 thumbnail = "https://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/11/now95_penguins_HRsmall-200x200.jpg" ,
 folder = True )
 if 62 - 62: Ooo00oOo00o / OoOOO00
 plugintools . add_item (

 title = "Now 94" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0O0OO0O + "/" ,
 thumbnail = "https://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/08/NOW_94-200x200.jpg" ,
 folder = True )
 if 7 - 7: OoooooooOO . OOo0ii11I1
 plugintools . add_item (

 title = "Now 93" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1i1II + "/" ,
 thumbnail = "http://www.officialcharts.com/media/650017/now-93-artwork.png?width=488.07157057654075&height=500" ,
 folder = True )
 if 53 - 53: o0o00o0O00 % o0o00o0O00 * OOO0o + I1IiI
 plugintools . add_item (

 title = "Now 92" ,
 url = "plugin://plugin.video.youtube/playlist/" + iI111iI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150923101439/now92GROTTO_HR-1024x1024.jpg" ,
 folder = True )
 if 92 - 92: OoooooooOO + i1IIi / o0o00o0O00 * O0
 plugintools . add_item (

 title = "Now 91" ,
 url = "plugin://plugin.video.youtube/playlist/" + iI1Ii11111iIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150611093502/now-91-CYMK-FINAL-HR-1024x1024.jpg" ,
 folder = True )
 if 100 - 100: oo00ooOoO00 % iIii1I11I1II1 * OoOoOO00 - I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 90" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0oO0 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/0/01/Now_90_UK_Cover.jpg" ,
 folder = True )
 if 92 - 92: oo00ooOoO00
 plugintools . add_item (

 title = "Now 89" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiII + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-89-Final-Artwork-1024x1024.jpg" ,
 folder = True )
 if 22 - 22: Oo % I11i1iIiIIIIIii * OoOOO00 / iIIII1iIIii % i11iIiiIii * oOOO00o000o
 plugintools . add_item (

 title = "Now 88" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiIIIII1i1iI + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/8/84/Now_88_UK_Cover.jpg" ,
 folder = True )
 if 95 - 95: OoooooooOO - OOo0ii11I1 * OOOo0 + I1IiI
 plugintools . add_item (

 title = "Now 87" ,
 url = "plugin://plugin.video.youtube/playlist/" + Iii1ii1II11i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now_87_EGG_final-1024x1024.jpg" ,
 folder = True )
 if 10 - 10: OOO0o / i11iIiiIii
 plugintools . add_item (

 title = "Now 86" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0oOoO00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now86NEW_FINAL-1024x1024.jpg" ,
 folder = True )
 if 92 - 92: oOOO00o000o . I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 85" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Pack-shot2-1024x1024.jpg" ,
 folder = True )
 if 85 - 85: OoOOO00 . I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 84" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0OOO + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/81087xfVSDL._SL1500_.jpg" ,
 folder = True )
 if 78 - 78: oo00ooOoO00 * I1iIi1iIiiIiI + iIii1I11I1II1 + iIii1I11I1II1 / I1iIi1iIiiIiI . o0o00o0O00
 plugintools . add_item (

 title = "Now 83" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIiiiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/08/NOW_83-200x200.jpg" ,
 folder = True )
 if 97 - 97: oo00ooOoO00 / I1iIi1iIiiIiI % i1IIi % OoOOO00
 plugintools . add_item (

 title = "Now 82" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0oO0ooo + "/" ,
 thumbnail = "http://tshop.r10s.com/3dc/0b1/5e1c/4b6d/20d8/3df1/8455/112ce49d9a005056b75a2f.jpg" ,
 folder = True )
 if 18 - 18: iIii1I11I1II1 % oOOO00o000o
 plugintools . add_item (

 title = "Now 81" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1i1iiI1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now-81.jpg" ,
 folder = True )
 if 95 - 95: oo00ooOoO00 + i11iIiiIii * I1iIi1iIiiIiI - i1IIi * I1iIi1iIiiIiI - iIii1I11I1II1
 plugintools . add_item (

 title = "Now 80" ,
 url = "plugin://plugin.video.youtube/playlist/" + o00 + "/" ,
 thumbnail = "http://i47.tinypic.com/o360l.jpg" ,
 folder = True )
 if 75 - 75: OoooooooOO * OOo0ii11I1
 plugintools . add_item (

 title = "Now 79" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0oo0OO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW79_F_flop_CYMK-1024x1024.jpg" ,
 folder = True )
 if 9 - 9: OOo0ii11I1 - OoOoOO00 + O0 / iIii1I11I1II1 / i11iIiiIii
 plugintools . add_item (

 title = "Now 78" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/3/3b/Now78UK.jpg" ,
 folder = True )
 if 39 - 39: OOo0ii11I1 * Oo + iIii1I11I1II1 - OOo0ii11I1 + iIIII1iIIii
 plugintools . add_item (

 title = "Now 77" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOoo00O0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/N77snowboardYEL-1024x1024.jpg" ,
 folder = True )
 if 69 - 69: O0
 plugintools . add_item (

 title = "Now 76" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1111 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now76HR-1024x1024.jpg" ,
 folder = True )
 if 85 - 85: oo00ooOoO00 / O0
 plugintools . add_item (

 title = "Now 75" ,
 url = "plugin://plugin.video.youtube/playlist/" + i11 + "/" ,
 thumbnail = "http://www.covershut.com/covers/NOW-Thats-What-I-Call-Music!-75-2010-Front-Cover-37348.jpg" ,
 folder = True )
 if 18 - 18: OOO0o % O0 * OoOOO00
 plugintools . add_item (

 title = "Now 74" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now74Sflakes_final-1024x1024.jpg" ,
 folder = True )
 if 62 - 62: I1iIi1iIiiIiI . OOo0ii11I1 . OoooooooOO
 plugintools . add_item (

 title = "Now 73" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0o0000o0o0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/N73_FINAL_HR-1024x1024.jpg" ,
 folder = True )
 if 11 - 11: iIIII1iIIii / oOOO00o000o
 plugintools . add_item (

 title = "Now 72" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOo0oooo00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-72-1024x1024.jpg" ,
 folder = True )
 if 73 - 73: i1IIi / i11iIiiIii
 plugintools . add_item (

 title = "Now 71" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0o0o0ooO0oO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-71-1024x1024.jpg" ,
 folder = True )
 if 58 - 58: Oo . OoOoOO00 + II1111ii - i11iIiiIii / OoOoOO00 / O0
 plugintools . add_item (

 title = "Now 70" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo0o0O00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-70-1024x1024.jpg" ,
 folder = True )
 if 85 - 85: I1IiI + iIIII1iIIii
 plugintools . add_item (

 title = "Now 69" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-69-1024x1024.jpg" ,
 folder = True )
 if 10 - 10: OOo0ii11I1 / Ooo00oOo00o + I1IiI / i1IIi
 plugintools . add_item (

 title = "Now 68" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1iiIIiiI111 + "/" ,
 thumbnail = "https://images-na.ssl-images-amazon.com/images/I/61tRYeXQQCL.jpg" ,
 folder = True )
 if 27 - 27: o0o00o0O00
 plugintools . add_item (

 title = "Now 67" ,
 url = "plugin://plugin.video.youtube/playlist/" + oooOOOOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-67-1024x1024.jpg" ,
 folder = True )
 if 67 - 67: OOOo0
 plugintools . add_item (

 title = "Now 66" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1iiIII111ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-66-1024x1024.jpg" ,
 folder = True )
 if 55 - 55: OoOOO00 - I11i1iIiIIIIIii * OOO0o + I1IiI * I1IiI * O0
 plugintools . add_item (

 title = "Now 65" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1iIIi1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-65-1024x1024.jpg" ,
 folder = True )
 if 91 - 91: I1iIi1iIiiIiI - iIIII1iIIii % iIii1I11I1II1 - OoooooooOO % oo00ooOoO00
 plugintools . add_item (

 title = "Now 64" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii11iIi1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-64-1024x1024.jpg" ,
 folder = True )
 if 98 - 98: Ooo00oOo00o . Ooo00oOo00o * II1111ii * OoOoOO00 * I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 63" ,
 url = "plugin://plugin.video.youtube/playlist/" + iI111I11I1I1 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/a/ae/Now_63.jpg" ,
 folder = True )
 if 92 - 92: Oo
 plugintools . add_item (

 title = "Now 62" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOooO0OOoo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-62-1024x1024.jpg" ,
 folder = True )
 if 40 - 40: I1IiI / OOo0ii11I1
 plugintools . add_item (

 title = "Now 61" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIii1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-61.jpg" ,
 folder = True )
 if 79 - 79: Ooo00oOo00o - iIii1I11I1II1 + o0o00o0O00 - I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 60" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOoO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-60-1024x1024.jpg" ,
 folder = True )
 if 93 - 93: OoOoOO00 . OOOo0 - Oo + I1IiI
 plugintools . add_item (

 title = "Now 59" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0OoO000O0OO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-59-1024x1024.jpg" ,
 folder = True )
 if 61 - 61: OoOoOO00
 plugintools . add_item (

 title = "Now 58" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiI1IiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-58-1024x1024.jpg" ,
 folder = True )
 if 15 - 15: i11iIiiIii % OOOo0 * oOOO00o000o / I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 57" ,
 url = "plugin://plugin.video.youtube/playlist/" + II + "/" ,
 thumbnail = "https://photos.prnewswire.com/prnvar/20160105/319490" ,
 folder = True )
 if 90 - 90: I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 56" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooOoOoo0O + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/91QvXvWXU1L._SY355_.jpg" ,
 folder = True )
 if 31 - 31: iIIII1iIIii + O0
 plugintools . add_item (

 title = "Now 55" ,
 url = "plugin://plugin.video.youtube/playlist/" + OooO0 + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/71kFlRrz8aL._SX355_.jpg" ,
 folder = True )
 if 87 - 87: oo00ooOoO00
 plugintools . add_item (

 title = "Now 54" ,
 url = "plugin://plugin.video.youtube/playlist/" + II11iiii1Ii + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/5/52/Now_54.jpg" ,
 folder = True )
 if 45 - 45: Ooo00oOo00o / OoooooooOO - I11i1iIiIIIIIii / o0o00o0O00 % OOo0ii11I1
 plugintools . add_item (

 title = "Now 53" ,
 url = "plugin://plugin.video.youtube/playlist/" + OO0o + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/5/58/Now_53.jpg" ,
 folder = True )
 if 83 - 83: OOOo0 . iIii1I11I1II1 - OOo0ii11I1 * i11iIiiIii
 plugintools . add_item (

 title = "Now 52" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ooo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/c/c1/Now_52.jpg" ,
 folder = True )
 if 20 - 20: i1IIi * I1iIi1iIiiIiI + OoOoOO00 % OOO0o % II1111ii
 plugintools . add_item (

 title = "Now 51" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0o0Oo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/1/1b/Now_51.jpg" ,
 folder = True )
 if 13 - 13: Oo
 plugintools . add_item (

 title = "Now 50" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo00OOOOO + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/b/b3/Now_50.jpg" ,
 folder = True )
 if 60 - 60: OoOOO00 * OOOo0
 plugintools . add_item (

 title = "Now 49" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0O + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/1/11/Now_49.jpg" ,
 folder = True )
 if 17 - 17: iIIII1iIIii % Oo / OoOOO00 . OOo0ii11I1 * iIIII1iIIii - OoOoOO00
 plugintools . add_item (

 title = "Now 48" ,
 url = "plugin://plugin.video.youtube/playlist/" + O00o0OO + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/2/20/Now_48.jpg" ,
 folder = True )
 if 41 - 41: o0o00o0O00
 plugintools . add_item (

 title = "Now 47" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11i1 + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/81ynokvm4ML._SL1500_.jpg" ,
 folder = True )
 if 77 - 77: I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now 46" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIi1ii1I1 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/c/c0/Now_46.jpg" ,
 folder = True )
 if 65 - 65: OoOoOO00 . OOOo0 % II1111ii * Ooo00oOo00o
 plugintools . add_item (

 title = "Now 45" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/3/36/Now_45.jpg" ,
 folder = True )
 if 38 - 38: I1IiI / I11i1iIiIIIIIii % Oo
 plugintools . add_item (

 title = "Now 44" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11II1i + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/6/60/Now_44.jpg" ,
 folder = True )
 if 11 - 11: I11i1iIiIIIIIii - II1111ii + OoOoOO00 - iIii1I11I1II1
 plugintools . add_item (

 title = "Now 43" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIII + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/f/ff/Now_43.jpg" ,
 folder = True )
 if 7 - 7: OOo0ii11I1 - oOOO00o000o / OoOoOO00 * o0o00o0O00 . I11i1iIiIIIIIii * I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 42" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooooooO0oo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/c/c7/Now_42.jpg" ,
 folder = True )
 if 61 - 61: oOOO00o000o % oo00ooOoO00 - Ooo00oOo00o / Oo
 plugintools . add_item (

 title = "Now 41" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIiiiiiiIi1I1 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/d/d6/Now_41.jpg" ,
 folder = True )
 if 4 - 4: OoooooooOO - i1IIi % o0o00o0O00 - iIIII1iIIii * OOO0o
 plugintools . add_item (

 title = "Now 40" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1IIIii + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/5/56/Now_40.jpg" ,
 folder = True )
 if 85 - 85: OoooooooOO * iIii1I11I1II1 . I11i1iIiIIIIIii / OoooooooOO % OOOo0 % O0
 plugintools . add_item (

 title = "Now 39" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOoOooOo0o0 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/e/e8/Now_39.jpg" ,
 folder = True )
 if 36 - 36: o0o00o0O00 / OoOoOO00 / OOo0ii11I1 / OOo0ii11I1 + OoOOO00
 plugintools . add_item (

 title = "Now 38" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-38-1024x1024.jpg" ,
 folder = True )
 if 95 - 95: OOo0ii11I1
 plugintools . add_item (

 title = "Now 37" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOO00 + "/" ,
 thumbnail = "http://cps-static.rovicorp.com/3/JPG_400/MI0002/367/MI0002367718.jpg?partner=allrovi.com" ,
 folder = True )
 if 51 - 51: OoOoOO00 + OOo0ii11I1 . i1IIi . OoOOO00 + I1IiI * OOOo0
 plugintools . add_item (

 title = "Now 36" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiiiiIIii + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/e/ef/Now_36.jpg" ,
 folder = True )
 if 72 - 72: II1111ii + II1111ii / OoOoOO00 . OoooooooOO % o0o00o0O00
 plugintools . add_item (

 title = "Now 35" ,
 url = "plugin://plugin.video.youtube/playlist/" + O000OO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-35-1024x1003.jpg" ,
 folder = True )
 if 49 - 49: II1111ii . Ooo00oOo00o - Oo * OoooooooOO . Oo
 plugintools . add_item (

 title = "Now 34" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11iii1Ii + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/a/a6/Now_34.jpg" ,
 folder = True )
 if 2 - 2: OoooooooOO % iIIII1iIIii
 plugintools . add_item (

 title = "Now 33" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1IIiiIiii + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/d/d6/Now_33.jpg" ,
 folder = True )
 if 63 - 63: OOOo0 % iIii1I11I1II1
 plugintools . add_item (

 title = "Now 32" ,
 url = "plugin://plugin.video.youtube/playlist/" + O000oo0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-32-150x150.jpg" ,
 folder = True )
 if 39 - 39: I11i1iIiIIIIIii / OoOoOO00 / OoOOO00 % OOOo0
 plugintools . add_item (

 title = "Now 31" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOOOi11i1 + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/1/15/Now_31.jpg" ,
 folder = True )
 if 89 - 89: I1iIi1iIiiIiI + OoooooooOO + I1iIi1iIiiIiI * i1IIi + iIii1I11I1II1 % oOOO00o000o
 plugintools . add_item (

 title = "Now 30" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIii1II1II + "/" ,
 thumbnail = "http://cdn.hitfix.com/photos/71216/Now30Front_rz_img_featured_photo_gallery.jpg" ,
 folder = True )
 if 59 - 59: iIIII1iIIii + i11iIiiIii
 plugintools . add_item (

 title = "Now 29" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1I1iI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-29-150x150.jpg" ,
 folder = True )
 if 88 - 88: i11iIiiIii - oo00ooOoO00
 plugintools . add_item (

 title = "Now 28" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo0OooOOo0 + "/" ,
 thumbnail = "http://images.coveralia.com/audio/n/Now_28--Frontal.jpg" ,
 folder = True )
 if 67 - 67: iIIII1iIIii . Oo + I1IiI - OoooooooOO
 plugintools . add_item (

 title = "Now 27" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0O + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/8/80/Now_That's_What_I_Call_Music!_27_(UK_series)_.jpg" ,
 folder = True )
 if 70 - 70: iIIII1iIIii / OoOoOO00 - iIii1I11I1II1 - I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 26" ,
 url = "plugin://plugin.video.youtube/playlist/" + O00oO + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/41cCLInJypL._SX355_.jpg" ,
 folder = True )
 if 11 - 11: iIii1I11I1II1 . OoooooooOO . OoOoOO00 / i1IIi - oOOO00o000o
 plugintools . add_item (

 title = "Now 25" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11i1I1I + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/61TH%2BnVIC2L._SY300_.jpg" ,
 folder = True )
 if 30 - 30: I1IiI
 plugintools . add_item (

 title = "Now 24" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0Oo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/7/7e/Now_24.jpg" ,
 folder = True )
 if 21 - 21: i11iIiiIii / I1iIi1iIiiIiI % iIIII1iIIii * O0 . oOOO00o000o - iIii1I11I1II1
 plugintools . add_item (

 title = "Now 23" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOoo0Oo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/4/40/Now_23.jpg" ,
 folder = True )
 if 26 - 26: OoOoOO00 * I1IiI
 plugintools . add_item (

 title = "Now 22" ,
 url = "plugin://plugin.video.youtube/playlist/" + o00OO00OoO + "/" ,
 thumbnail = "http://www.music-bazaar.com/album-images/vol1/96/96327/612368-big/Now-That-S-What-I-Call-Music-22-cover.jpg" ,
 folder = True )
 if 10 - 10: OoOoOO00 . I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 21" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOOO0OOoO0O0 + "/" ,
 thumbnail = "http://www.yosmusic.com/wp-content/uploads/2016/02/Now-21-%D7%97%D7%93%D7%A9.jpg" ,
 folder = True )
 if 32 - 32: o0o00o0O00 . OOo0ii11I1 . OoooooooOO - Ooo00oOo00o + II1111ii
 plugintools . add_item (

 title = "Now 20" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0Oo000ooO00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-20-high-res-150x150.jpg" ,
 folder = True )
 if 88 - 88: I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 19" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-19-high-res-150x150.jpg" ,
 folder = True )
 if 19 - 19: OoOoOO00 * OOo0ii11I1 + o0o00o0O00
 plugintools . add_item (

 title = "Now 18" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii1iIiII1ii1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-18-high-res-150x150.jpg" ,
 folder = True )
 if 65 - 65: iIIII1iIIii . I1iIi1iIiiIiI . Ooo00oOo00o . I11i1iIiIIIIIii - iIIII1iIIii
 plugintools . add_item (

 title = "Now 17" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooOooo000oOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-17-high-res-150x150.jpg" ,
 folder = True )
 if 19 - 19: i11iIiiIii + I11i1iIiIIIIIii % oo00ooOoO00
 plugintools . add_item (

 title = "Now 16" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0oOOo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-16-high-res-150x150.jpg" ,
 folder = True )
 if 14 - 14: Ooo00oOo00o . OoOoOO00 . oOOO00o000o / o0o00o0O00 % OoOOO00 - oo00ooOoO00
 plugintools . add_item (

 title = "Now 15" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0OoO00oOO0o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-15-150x150.jpg" ,
 folder = True )
 if 67 - 67: oOOO00o000o - iIIII1iIIii . i1IIi
 plugintools . add_item (

 title = "Now 14" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOO00O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-14-150x150.jpg" ,
 folder = True )
 if 35 - 35: I11i1iIiIIIIIii + oo00ooOoO00 - II1111ii . I11i1iIiIIIIIii . OOo0ii11I1
 plugintools . add_item (

 title = "Now 13" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOoOO0oo0ooO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-13-high-res.jpg" ,
 folder = True )
 if 87 - 87: I1IiI
 plugintools . add_item (

 title = "Now 12" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0o0O00Oo0o0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-12-150x150.jpg" ,
 folder = True )
 if 25 - 25: i1IIi . Ooo00oOo00o - I1IiI / Ooo00oOo00o % Ooo00oOo00o * iIii1I11I1II1
 plugintools . add_item (

 title = "Now 11" ,
 url = "plugin://plugin.video.youtube/playlist/" + O00O0oOO00O00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-11-150x150.jpg" ,
 folder = True )
 if 50 - 50: Ooo00oOo00o . i11iIiiIii - II1111ii . II1111ii
 plugintools . add_item (

 title = "Now 10" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1Oo00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-10-150x150.jpg" ,
 folder = True )
 if 31 - 31: iIIII1iIIii / Oo * i1IIi . I1IiI
 plugintools . add_item (

 title = "Now 9" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1i + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/1/14/Now_9_United_Kingdom.jpg" ,
 folder = True )
 if 57 - 57: iIIII1iIIii + iIii1I11I1II1 % i1IIi % OOOo0
 plugintools . add_item (

 title = "Now 8" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiI111I1iIiI + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/a/aa/Now_8_United_Kingdom.jpg" ,
 folder = True )
 if 83 - 83: OOO0o / i11iIiiIii % iIii1I11I1II1 . oOOO00o000o % II1111ii . OoooooooOO
 plugintools . add_item (

 title = "Now 7" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIi1I1IIii1II + "/" ,
 thumbnail = "http://rymimg.com/lk/f/l/c33af130e24ba021d2b963fa81008e24/2391455.jpg" ,
 folder = True )
 if 94 - 94: o0o00o0O00 + iIii1I11I1II1 % Ooo00oOo00o
 plugintools . add_item (

 title = "Now 6" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0ii1ii1ii + "/" ,
 thumbnail = "http://ecx.images-amazon.com/images/I/818bzGDAdjL._SY355_.jpg" ,
 folder = True )
 if 93 - 93: o0o00o0O00 - iIIII1iIIii + iIii1I11I1II1 * OOO0o + I1iIi1iIiiIiI . I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now 5" ,
 url = "plugin://plugin.video.youtube/playlist/" + oooooOoo0ooo + "/" ,
 thumbnail = "https://upload.wikimedia.org/wikipedia/en/1/1b/Now_5.jpg" ,
 folder = True )
 if 49 - 49: OoooooooOO * oOOO00o000o - Oo . II1111ii
 plugintools . add_item (

 title = "Now 4" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1I1IiI1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-4-high-res-150x150.jpg" ,
 folder = True )
 if 89 - 89: oo00ooOoO00 + o0o00o0O00 * oo00ooOoO00 / oo00ooOoO00
 plugintools . add_item (

 title = "Now 3" ,
 url = "plugin://plugin.video.youtube/playlist/" + III1iII1I1ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-3-high-res-150x150.jpg" ,
 folder = True )
 if 46 - 46: Ooo00oOo00o
 plugintools . add_item (

 title = "Now 2" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-2-high-res-150x150.jpg" ,
 folder = True )
 if 71 - 71: oOOO00o000o / oOOO00o000o * II1111ii * II1111ii / OoOoOO00
 plugintools . add_item (

 title = "Now 1" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo00O00oO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Copy-of-Now-1-150x150.jpg" ,
 folder = True )
 if 35 - 35: iIIII1iIIii * OOO0o * OOOo0 % Oo . I1IiI
 plugintools . add_item (

 title = "Now 80s Party" ,
 url = "plugin://plugin.video.youtube/playlist/" + II1iiiiII + "/" ,
 thumbnail = "https://scontent-lhr3-1.xx.fbcdn.net/v/t1.0-0/c14.0.200.200/p200x200/22310330_10155773229241624_2091795701253408455_n.jpg?oh=789238c8cf065b524079261ebaca21b8&oe=5A736912" ,
 folder = True )
 if 58 - 58: oOOO00o000o + OoOoOO00 * I11i1iIiIIIIIii * i11iIiiIii - iIii1I11I1II1
 plugintools . add_item (

 title = "Now Country" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0OoO00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/10/Country_Chosen-1500x1500-200x200.png" ,
 folder = True )
 if 68 - 68: OoooooooOO % OoOoOO00
 plugintools . add_item (

 title = "Now 60's" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIII1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/09/NOW-60S-HR-200x200.jpg" ,
 folder = True )
 if 26 - 26: OoOoOO00 % i11iIiiIii % iIii1I11I1II1 % oOOO00o000o * oOOO00o000o * OoOOO00
 plugintools . add_item (

 title = "Now 00's" ,
 url = "plugin://plugin.video.youtube/playlist/" + I111i1i1111 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/10/now-00s_High_Res-200x200.jpg" ,
 folder = True )
 if 24 - 24: OoOoOO00 % I1iIi1iIiiIiI - oo00ooOoO00 + OOOo0 * OoOOO00
 plugintools . add_item (

 title = "Now Disney 2017" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii111 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/09/Now-Disney_1500x1500pxls_rgb-200x200.png" ,
 folder = True )
 if 2 - 2: o0o00o0O00 - OOo0ii11I1
 plugintools . add_item (

 title = "Now Million" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii1II1I11i1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/09/NOW-million-200x200.jpg" ,
 folder = True )
 if 83 - 83: II1111ii % OOO0o % o0o00o0O00 - OoOoOO00 * iIIII1iIIii / OoooooooOO
 plugintools . add_item (

 title = "Now Sing" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0o0O0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/08/now-SING-15-200x200.jpg" ,
 folder = True )
 if 18 - 18: Ooo00oOo00o + iIii1I11I1II1 - OoOoOO00 - OOOo0
 plugintools . add_item (

 title = "Now Old Skool" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOoOooOoOOOoo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/07/Now_OldSkool_1500x1500-300x300.png" ,
 folder = True )
 if 71 - 71: OoooooooOO
 if 33 - 33: I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now Summer Party 2017" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOIIiIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/05/SUMMER-PARTY-2-200x200.png" ,
 folder = True )
 if 62 - 62: OoOOO00 + o0o00o0O00 + i1IIi / OoooooooOO
 plugintools . add_item (

 title = "Now Driving Rock" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0Oooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/05/Driving-Rock-200x200.png" ,
 folder = True )
 if 7 - 7: OOO0o + i1IIi . OOOo0 / Oo
 plugintools . add_item (

 title = "Now Classic Rock (vinyl)" ,
 url = "plugin://plugin.video.youtube/playlist/" + OO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2017/05/NOW_Classic_Rock_Small-200x200.jpg" ,
 folder = True )
 if 22 - 22: oo00ooOoO00 - oo00ooOoO00 % iIIII1iIIii . I1iIi1iIiiIiI + II1111ii
 plugintools . add_item (

 title = "Now Classic Soul" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOo0O0oo0OO0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now_classic_soul_goldNEW-1024x1024.jpg" ,
 folder = True )
 if 63 - 63: OOOo0 % I1iIi1iIiiIiI * OOO0o + I1iIi1iIiiIiI / Oo % I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now Running 2017" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0o0O00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-Run_Chosen-red-Lres-150x150.jpg" ,
 folder = True )
 if 45 - 45: OOo0ii11I1
 plugintools . add_item (

 title = "Now Mum" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooo00Ooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-MUM-COVER-150x150.jpg" ,
 folder = True )
 if 20 - 20: OoooooooOO * OOO0o * O0 . iIIII1iIIii
 plugintools . add_item (

 title = "Now R&B 2017" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOO0O00Oo0O0o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now_RB_skyscrapers_300dpi-1024x1024.jpg" ,
 folder = True )
 if 78 - 78: iIii1I11I1II1 + oOOO00o000o - o0o00o0O00 * I1iIi1iIiiIiI - OoooooooOO % I1IiI
 plugintools . add_item (

 title = "Now Party Hits" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/1500x1500_NowPartyHits-copy-1024x1024.jpg" ,
 folder = True )
 if 34 - 34: O0
 plugintools . add_item (

 title = "Now 70's" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1iIIiiIIi1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_70s-150x150.jpg" ,
 folder = True )
 if 80 - 80: i1IIi - Oo / Ooo00oOo00o - i11iIiiIii
 plugintools . add_item (

 title = "Now Love" ,
 url = "plugin://plugin.video.youtube/playlist/" + OO0Oooo0oOO0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-LOVE-COVER-150x150.jpg" ,
 folder = True )
 if 68 - 68: II1111ii - OoOOO00 % O0 % I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now N0.1 Hits" ,
 url = "plugin://plugin.video.youtube/playlist/" + o00O0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-No.1s-1500X1500-150x150.jpg" ,
 folder = True )
 if 11 - 11: O0 / Ooo00oOo00o % iIIII1iIIii + OOO0o + iIii1I11I1II1
 plugintools . add_item (

 title = "Now 20th Century" ,
 url = "plugin://plugin.video.youtube/playlist/" + OO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Century-150x150.jpg" ,
 folder = True )
 if 40 - 40: oo00ooOoO00 - iIIII1iIIii . o0o00o0O00 * Oo % I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now Drivetime" ,
 url = "plugin://plugin.video.youtube/playlist/" + OoOoO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-DRIVE-1500X1500-150x150.jpg" ,
 folder = True )
 if 56 - 56: i11iIiiIii . OOO0o - OOOo0 * oOOO00o000o
 plugintools . add_item (

 title = "Now Summer Hits" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIiIIIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/summerHitsFinal-150x150.jpeg" ,
 folder = True )
 if 91 - 91: II1111ii + OoooooooOO - i1IIi
 plugintools . add_item (

 title = "Now Reggae" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooo00OOOooO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Reggae-Square-150x150.jpg" ,
 folder = True )
 if 84 - 84: o0o00o0O00 / OOo0ii11I1
 plugintools . add_item (

 title = "Now Rock Ballards" ,
 url = "plugin://plugin.video.youtube/playlist/" + O00OOOoOoo0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_ROCK_Square-150x150.png" ,
 folder = True )
 if 86 - 86: I1IiI * OoOoOO00 - O0 . I1IiI % iIii1I11I1II1 / iIIII1iIIii
 plugintools . add_item (

 title = "Now Fitness" ,
 url = "plugin://plugin.video.youtube/playlist/" + O000OOo00oo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Fitness-final-150x150.png" ,
 folder = True )
 if 11 - 11: OOOo0 * II1111ii + OoOOO00 / OoOOO00
 plugintools . add_item (

 title = "Now Brit Hits" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo0OOo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/brits-png-150x150.png" ,
 folder = True )
 if 37 - 37: i11iIiiIii + i1IIi
 plugintools . add_item (

 title = "Now Party Anthems" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooOOO00Ooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150916134350/2015_NOW_Party_Anthems-150x150.jpg" ,
 folder = True )
 if 23 - 23: I11i1iIiIIIIIii + oOOO00o000o . I1IiI * OOOo0 + OoOOO00
 plugintools . add_item (

 title = "Now Classical" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiIIIi1iIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20151029180744/NOW-Classical-standard-150x150.jpg" ,
 folder = True )
 if 18 - 18: OOo0ii11I1 * OOO0o . OOo0ii11I1 / O0
 plugintools . add_item (

 title = "Now 80s" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooOOoooooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150814114139/NOW_80s_Hi_Res-150x150.jpg" ,
 folder = True )
 if 8 - 8: OOO0o
 plugintools . add_item (

 title = "Now Singer" ,
 url = "plugin://plugin.video.youtube/playlist/" + II1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150814113921/NOW_Singer_Hi_Res-150x150.jpg" ,
 folder = True )
 if 4 - 4: OoOOO00 + OoOOO00 * oo00ooOoO00 - I1IiI
 plugintools . add_item (

 title = "Now Pop" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0i1II1Iiii1I11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150814113736/NOW_Pop_Hi_Res-150x150.jpg" ,
 folder = True )
 if 78 - 78: o0o00o0O00 / OoOoOO00 % I1IiI
 plugintools . add_item (

 title = "Now House" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIII + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150715142220/Now_House_HighRes-150x150.png" ,
 folder = True )
 if 52 - 52: iIIII1iIIii - I11i1iIiIIIIIii * II1111ii
 plugintools . add_item (

 title = "Now Summer Party" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiIiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150528112315/NOW-SUMMER-PARTY-HR--150x150.jpg" ,
 folder = True )
 if 17 - 17: OoooooooOO + iIIII1iIIii * oOOO00o000o * I1IiI
 plugintools . add_item (

 title = "Now Classic Rock" ,
 url = "plugin://plugin.video.youtube/playlist/" + o00oooO0Oo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/20150501160046/NOW_Classic_Rock_Small-150x150.jpg" ,
 folder = True )
 if 36 - 36: O0 + Oo
 plugintools . add_item (

 title = "Now Running 2015" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0O0OOO0Ooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now_running_2015_W_BottleCYMK-150x150.jpg" ,
 folder = True )
 if 5 - 5: Oo * I1IiI
 plugintools . add_item (

 title = "Now RSDR" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiIiII1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_1_RSD-150x150.jpg" ,
 folder = True )
 if 46 - 46: oo00ooOoO00
 plugintools . add_item (

 title = "Now Song" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOO00O0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Song_High_res-150x150.jpg" ,
 folder = True )
 if 33 - 33: I11i1iIiIIIIIii - OoOoOO00 * OoooooooOO - Oo - iIIII1iIIii
 plugintools . add_item (

 title = "Now Power Ballads" ,
 url = "plugin://plugin.video.youtube/playlist/" + iii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Power_Ballads-150x150.png" ,
 folder = True )
 if 84 - 84: I1iIi1iIiiIiI + Oo - I1IiI * I1IiI
 plugintools . add_item (

 title = "Now Party" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOooOOOoOo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-Party-150x150.jpg" ,
 folder = True )
 if 61 - 61: OoooooooOO . II1111ii . OoooooooOO / Oo
 plugintools . add_item (

 title = "Now Disney Princess" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1Iii1i1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/1500x1500_Now-Princess-2016-150x150.png" ,
 folder = True )
 if 72 - 72: i1IIi
 plugintools . add_item (

 title = "Now Musicals 2014" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOoO00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWMusicals2-150x150.png" ,
 folder = True )
 if 82 - 82: I1IiI + OoooooooOO / i11iIiiIii * OoOOO00 . OoooooooOO
 plugintools . add_item (

 title = "Now Legends" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiI111111IIII + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Legends-150x150.png" ,
 folder = True )
 if 63 - 63: OoOOO00
 plugintools . add_item (

 title = "Now 90s" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1Ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-90s-rough-150x150.jpg" ,
 folder = True )
 if 6 - 6: oo00ooOoO00 / OoOOO00
 plugintools . add_item (

 title = "Now Disney" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii111iI1iIi1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-DISNEY-2014-v1-150x150.png" ,
 folder = True )
 if 57 - 57: oOOO00o000o
 plugintools . add_item (

 title = "Now Million" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_million3-150x150.png" ,
 folder = True )
 if 67 - 67: Ooo00oOo00o . oo00ooOoO00
 plugintools . add_item (

 title = "Now Drive" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo0OOo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Drive-150x150.jpg" ,
 folder = True )
 if 87 - 87: II1111ii % o0o00o0O00
 plugintools . add_item (

 title = "Now Club Hits 2014" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11IiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Club_Hits_2014-150x150.jpg" ,
 folder = True )
 if 83 - 83: OoOoOO00 - oOOO00o000o
 plugintools . add_item (

 title = "Now Chilled" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0ooO0Oo00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Chilled-150x150.jpg" ,
 folder = True )
 if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
 plugintools . add_item (

 title = " Now Summer" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooO0oOOooOo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Summer-150x150.png" ,
 folder = True )
 if 86 - 86: iIii1I11I1II1 + I1IiI . i11iIiiIii - o0o00o0O00
 plugintools . add_item (

 title = "Now Rock" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1I1ii11i1Iii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-ROCK-HR-DIGI-150x150.jpg" ,
 folder = True )
 if 51 - 51: I1IiI
 plugintools . add_item (

 title = "Now 21st Century" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1IiiiiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_21st_Century_Final-150x150.jpg" ,
 folder = True )
 if 14 - 14: OOo0ii11I1 % II1111ii % Oo - i11iIiiIii
 plugintools . add_item (

 title = "Now Feel Good" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0OIiII + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Feel_Good-150x150.jpg" ,
 folder = True )
 if 53 - 53: o0o00o0O00 % Oo
 plugintools . add_item (

 title = "Now Running 2014" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1iII1II + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_Running-150x150.jpg" ,
 folder = True )
 if 59 - 59: iIIII1iIIii % iIii1I11I1II1 . i1IIi + OoOoOO00 * OOo0ii11I1
 plugintools . add_item (

 title = "Now Club Hits 2013" ,
 url = "plugin://plugin.video.youtube/playlist/" + Iii1I1I11iiI1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Club-Hits-150x150.jpg" ,
 folder = True )
 if 41 - 41: o0o00o0O00 % OoOOO00
 plugintools . add_item (

 title = "Now Relaxing Classical" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1I1i1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Relaxing-Classical-150x150.jpg" ,
 folder = True )
 if 12 - 12: iIIII1iIIii
 plugintools . add_item (

 title = "Now Movies" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0oO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Movies-150x150.jpg" ,
 folder = True )
 if 69 - 69: OoooooooOO + iIIII1iIIii
 plugintools . add_item (

 title = "Now USA" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-USA-150x150.jpg" ,
 folder = True )
 if 26 - 26: Oo + iIIII1iIIii / Ooo00oOo00o % I1IiI % OoOOO00 + OoOoOO00
 plugintools . add_item (

 title = "Now Disco" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOI1iI1ii1II + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Disco-150x150.jpg" ,
 folder = True )
 if 31 - 31: oOOO00o000o % iIIII1iIIii * oOOO00o000o
 plugintools . add_item (

 title = "Now 30 Years" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0O0OOOOoo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now30years-150x150.jpg" ,
 folder = True )
 if 45 - 45: i1IIi . OOOo0 + iIIII1iIIii - OoooooooOO % oo00ooOoO00
 plugintools . add_item (

 title = "Now Musicals 2012" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOooO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-Musicals-hi-res-150x150.jpg" ,
 folder = True )
 if 1 - 1: iIii1I11I1II1
 plugintools . add_item (

 title = "Now Chill" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii1I1Ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/nowchill-150x150.jpg" ,
 folder = True )
 if 93 - 93: i1IIi . i11iIiiIii . Oo
 plugintools . add_item (

 title = "Now No1" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0O0ooOOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-No.1-150x150.jpg" ,
 folder = True )
 if 99 - 99: oOOO00o000o - I1iIi1iIiiIiI - II1111ii % Ooo00oOo00o
 plugintools . add_item (

 title = "Now Reggae" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOoO0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now-reggae-150x150.jpg" ,
 folder = True )
 if 21 - 21: OoOoOO00 % OoOOO00 . i1IIi - OoooooooOO
 plugintools . add_item (

 title = "Now Britain" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1i111I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Now-Music-NOW-That-s-What-I-Call-Britain-150x150.jpg" ,
 folder = True )
 if 4 - 4: OoooooooOO . oo00ooOoO00
 plugintools . add_item (

 title = "Now Running 2012" ,
 url = "plugin://plugin.video.youtube/playlist/" + OooOo0oo0O0o00O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-RUNNING_final_packshot-150x150.jpg" ,
 folder = True )
 if 78 - 78: OoOOO00 + oOOO00o000o - O0
 plugintools . add_item (

 title = "Now Love" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1i11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW_LOVE_HR-150x150.jpg" ,
 folder = True )
 if 10 - 10: I1iIi1iIiiIiI % OOOo0
 plugintools . add_item (

 title = "Now Classical 2011" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiIi1I1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now-classical-150x150.jpg" ,
 folder = True )
 if 97 - 97: OoooooooOO - I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now R&B 2011" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiIIi1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/nowrb-150x150.jpg" ,
 folder = True )
 if 58 - 58: iIii1I11I1II1 + O0
 plugintools . add_item (

 title = "Now Wedding" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIIiii1IIii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/nowwedding-150x150.jpg" ,
 folder = True )
 if 30 - 30: oo00ooOoO00 % I11i1iIiIIIIIii * iIIII1iIIii - OoOOO00 * o0o00o0O00 % oo00ooOoO00
 plugintools . add_item (

 title = "Now 00s" ,
 url = "plugin://plugin.video.youtube/playlist/" + II1i11I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/now00s-150x150.jpg" ,
 folder = True )
 if 46 - 46: i11iIiiIii - O0 . II1111ii
 plugintools . add_item (

 title = "Now 90s" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1I1IIii11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-90s-150x150.jpg" ,
 folder = True )
 if 100 - 100: OOOo0 / OOO0o * I11i1iIiIIIIIii . O0 / iIIII1iIIii
 plugintools . add_item (

 title = "Now 25 Years" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0o0oO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-25-Years-150x150.jpg" ,
 folder = True )
 if 83 - 83: I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now The 80s" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIIiIiIi1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-80s-150x150.jpg" ,
 folder = True )
 if 48 - 48: OoOoOO00 * iIIII1iIIii * I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now No1 2006" ,
 url = "plugin://plugin.video.youtube/playlist/" + I11iiiiI1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWno1s-150x150.jpg" ,
 folder = True )
 if 50 - 50: OOo0ii11I1 % i1IIi
 plugintools . add_item (

 title = "Now Music Years" ,
 url = "plugin://plugin.video.youtube/playlist/" + iI1i11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Years1-150x150.jpg" ,
 folder = True )
 if 21 - 21: OoooooooOO - iIii1I11I1II1
 plugintools . add_item (

 title = "Now Decades" ,
 url = "plugin://plugin.video.youtube/playlist/" + OoOOoooOO0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Decades-150x150.jpg" ,
 folder = True )
 if 93 - 93: II1111ii - OOO0o % I1IiI . I1IiI - oo00ooOoO00
 plugintools . add_item (

 title = "Now Dance Hits" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOo0O00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-DANCE-COVER--150x150.jpg" ,
 folder = True )
 if 90 - 90: oo00ooOoO00 + OoOoOO00 * OoOOO00 / o0o00o0O00 . OOO0o + OOO0o
 plugintools . add_item (

 title = "Best Of Now Dance" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIiIi11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/Very-Best-of-NOW-Dance-150x150.png" ,
 folder = True )
 if 40 - 40: oo00ooOoO00 / I1IiI % i11iIiiIii % OoOOO00 / OOOo0
 plugintools . add_item (

 title = "Now 80's Dance" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOOiiiiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-80s-DANCE1-150x150.jpg" ,
 folder = True )
 if 62 - 62: i1IIi - I1IiI
 plugintools . add_item (

 title = "Now 90's Dance" ,
 url = "plugin://plugin.video.youtube/playlist/" + oooOo0OOOoo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-90S-FINAL-coverlrg1-150x150.jpg" ,
 folder = True )
 if 62 - 62: i1IIi + Oo % OOo0ii11I1
 plugintools . add_item (

 title = "Best Of Now Dance 2010" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOoO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/nowdance2010-150x150.jpg" ,
 folder = True )
 if 28 - 28: OoOOO00 . i1IIi
 plugintools . add_item (

 title = "Now Dance Anthems" ,
 url = "plugin://plugin.video.youtube/playlist/" + OO0O000 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Anthems-150x150.jpg" ,
 folder = True )
 if 10 - 10: Ooo00oOo00o / Oo
 plugintools . add_item (

 title = "Now Dance 2008" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiIiI1i1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/noedance2008-150x150.jpg" ,
 folder = True )
 if 15 - 15: I11i1iIiIIIIIii . I1IiI / I11i1iIiIIIIIii * oOOO00o000o - OOOo0 % OoOOO00
 plugintools . add_item (

 title = "Now Dance 2007" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0O00oOOoooO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE2007-150x150.jpg" ,
 folder = True )
 if 57 - 57: O0 % I1IiI % II1111ii
 plugintools . add_item (

 title = "Now The Very Best Of Dance (2005)" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiIi11iI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/The+Very+Best+of+Now+Dance+disc+1+cd-150x150.jpg" ,
 folder = True )
 if 45 - 45: OoOOO00 + OoOoOO00 * i11iIiiIii
 plugintools . add_item (

 title = "Now Dance 2005" ,
 url = "plugin://plugin.video.youtube/playlist/" + Oo0O00O000 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-2004-150x150.jpg" ,
 folder = True )
 if 13 - 13: OoooooooOO * II1111ii - o0o00o0O00 / iIIII1iIIii + oOOO00o000o + OOo0ii11I1
 plugintools . add_item (

 title = "Now Dance" ,
 url = "plugin://plugin.video.youtube/playlist/" + i11I1IiII1i1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/0724357751025-MF-150x150.jpg" ,
 folder = True )
 if 39 - 39: iIii1I11I1II1 - OoooooooOO
 plugintools . add_item (

 title = "Now Dance 2004" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooI1111i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/0724359149424-MF1-150x150.jpg" ,
 folder = True )
 if 81 - 81: OoOOO00 - O0 * OoooooooOO
 plugintools . add_item (

 title = "Now Dance 2003 (Part 2)" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIIii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/0724358252828-MF-150x150.jpg" ,
 folder = True )
 if 23 - 23: OoOoOO00 / II1111ii
 plugintools . add_item (

 title = "Now Dance 2003" ,
 url = "plugin://plugin.video.youtube/playlist/" + o00O0O + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/0724381308523-MF-150x150.jpg" ,
 folder = True )
 if 28 - 28: Oo * oo00ooOoO00 - Ooo00oOo00o
 plugintools . add_item (

 title = "Now Dance 2002 (Part 2)" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1iii1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/9314-MF-150x150.jpg" ,
 folder = True )
 if 19 - 19: oOOO00o000o
 plugintools . add_item (

 title = "Now Dance 2002" ,
 url = "plugin://plugin.video.youtube/playlist/" + Iii1I1111ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/8902-MF-150x150.jpg" ,
 folder = True )
 if 67 - 67: O0 % iIii1I11I1II1 / OOo0ii11I1 . i11iIiiIii - o0o00o0O00 + O0
 plugintools . add_item (

 title = "Now Dance 2001 (Part 2)" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooOoO00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/8628-MF-150x150.jpg" ,
 folder = True )
 if 27 - 27: iIIII1iIIii
 plugintools . add_item (

 title = "Now Dance 2001" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ii1IIiI1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/8207-MF-150x150.jpg" ,
 folder = True )
 if 89 - 89: OoOoOO00 / II1111ii
 plugintools . add_item (

 title = "Now Dance 2000" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0O00Oo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/7445-LF-150x150.jpg" ,
 folder = True )
 if 14 - 14: iIIII1iIIii . OOOo0 * oo00ooOoO00 + OoOoOO00 - oo00ooOoO00 + iIIII1iIIii
 plugintools . add_item (

 title = "Now Dance 98" ,
 url = "plugin://plugin.video.youtube/playlist/" + IiII111i1i11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE98-150x150.jpg" ,
 folder = True )
 if 18 - 18: II1111ii - OOO0o - OOOo0 - OOOo0
 plugintools . add_item (

 title = "Now Dance 97" ,
 url = "plugin://plugin.video.youtube/playlist/" + i111iIi1i1II1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE97-150x150.jpg" ,
 folder = True )
 if 54 - 54: Oo + OOOo0 / I11i1iIiIIIIIii . OOOo0 * I1IiI
 plugintools . add_item (

 title = "Now Dance Summer 95" ,
 url = "plugin://plugin.video.youtube/playlist/" + oooO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Summer-95-150x150.jpeg" ,
 folder = True )
 if 1 - 1: I1IiI * Ooo00oOo00o . i1IIi / Oo . OoOOO00 + Oo
 plugintools . add_item (

 title = "Now Dance 95" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1I1i111Ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE95-150x150.jpg" ,
 folder = True )
 if 17 - 17: Oo + Ooo00oOo00o / o0o00o0O00 / I11i1iIiIIIIIii * iIIII1iIIii
 plugintools . add_item (

 title = "Now Dance The Best Of 94" ,
 url = "plugin://plugin.video.youtube/playlist/" + ooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Best-94-150x150.jpg" ,
 folder = True )
 if 29 - 29: Ooo00oOo00o % OoooooooOO * II1111ii / OoOoOO00 - II1111ii
 plugintools . add_item (

 title = "Now Dance Summer 94" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1i1iI1iiiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Summer-94-150x150.jpg" ,
 folder = True )
 if 19 - 19: i11iIiiIii
 plugintools . add_item (

 title = "Now Dance 94 Vol 2" ,
 url = "plugin://plugin.video.youtube/playlist/" + Ooo0oOooo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE94VOL2-150x150.jpg" ,
 folder = True )
 if 54 - 54: OoOoOO00 . oOOO00o000o
 plugintools . add_item (

 title = "Now Dance 94 Vol 1" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOOOoo00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOWDANCE94VOL1-150x150.jpg" ,
 folder = True )
 if 73 - 73: I1IiI . OOOo0
 plugintools . add_item (

 title = "Now Dance The Best Of 93" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiIiIIIiiI + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Best-931-150x150.jpeg" ,
 folder = True )
 if 32 - 32: I1IiI * OOOo0 % oo00ooOoO00 * o0o00o0O00 . O0
 plugintools . add_item (

 title = "Now Dance 93" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiI1IIIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-93-150x150.jpg" ,
 folder = True )
 if 48 - 48: I11i1iIiIIIIIii * I11i1iIiIIIIIii
 plugintools . add_item (

 title = "Now Dance 92" ,
 url = "plugin://plugin.video.youtube/playlist/" + II11IiIi11 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-92-150x150.jpg" ,
 folder = True )
 if 13 - 13: o0o00o0O00 / oOOO00o000o + I1IiI . OOO0o % oo00ooOoO00
 plugintools . add_item (

 title = "Now Dance 91" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIOOO0O00O0OOOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-91-150x150.jpg" ,
 folder = True )
 if 48 - 48: OOOo0 / i11iIiiIii - OOO0o * II1111ii / OoooooooOO
 plugintools . add_item (

 title = "Now Dance 903" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1iiii1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-903-150x150.jpg" ,
 folder = True )
 if 89 - 89: iIii1I11I1II1 / OOOo0 - OoOoOO00 / o0o00o0O00 . i11iIiiIii . o0o00o0O00
 plugintools . add_item (

 title = "Now Dance 902" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-902-150x150.jpg" ,
 folder = True )
 if 48 - 48: O0 + O0 . I1iIi1iIiiIiI - oo00ooOoO00
 plugintools . add_item (

 title = "Now Dance 901" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO00ooooO0o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-901-150x150.jpg" ,
 folder = True )
 if 63 - 63: II1111ii
 plugintools . add_item (

 title = "Now Dance 89 The 12' Mixes" ,
 url = "plugin://plugin.video.youtube/playlist/" + oo0o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-89.jpg" ,
 folder = True )
 if 71 - 71: i1IIi . o0o00o0O00 * I11i1iIiIIIIIii % OoooooooOO + iIIII1iIIii
 plugintools . add_item (

 title = "Now Dance 86 The 12' Mixes" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0oO0oooOoo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-86-150x150.jpg" ,
 folder = True )
 if 36 - 36: OOo0ii11I1
 plugintools . add_item (

 title = "Now Dance Vol 1" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1III1111iIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/NOW-Dance-Vol-1-150x150.jpg" ,
 folder = True )
 if 49 - 49: iIIII1iIIii / OoooooooOO / OOOo0
 plugintools . add_item (

 title = "Now Millenium 1999" ,
 url = "plugin://plugin.video.youtube/playlist/" + Iiii1iI1i + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41BD4HWF30L-200x200.jpg" ,
 folder = True )
 if 74 - 74: I1iIi1iIiiIiI % OoOOO00
 plugintools . add_item (

 title = "Now Millenium 1998" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1ii1ii11i1I + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41AHBWHZK2L-200x200.jpg" ,
 folder = True )
 if 7 - 7: OoOoOO00
 plugintools . add_item (

 title = "Now Millenium 1997" ,
 url = "plugin://plugin.video.youtube/playlist/" + o0OoOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41K4QBW0XXL-200x200.jpg" ,
 folder = True )
 if 27 - 27: II1111ii . OoooooooOO + i11iIiiIii
 plugintools . add_item (

 title = "Now Millenium 1996" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0O0Oo00 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41KQJDQJYAL-200x200.jpg" ,
 folder = True )
 if 86 - 86: oOOO00o000o / OOO0o - OOO0o + OoOOO00 + II1111ii
 plugintools . add_item (

 title = "Now Millenium 1995" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOoO00o + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/9102c7q5-ZL._SL1198_-200x200.jpg" ,
 folder = True )
 if 33 - 33: OOO0o . I11i1iIiIIIIIii . OOo0ii11I1 . i1IIi
 plugintools . add_item (

 title = "Now Millenium 1994" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO00O0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41X8BVC2TYL-200x200.jpg" ,
 folder = True )
 if 49 - 49: OoOOO00
 plugintools . add_item (

 title = "Now Millenium 1993" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIi1IIIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41E1223CMQL-200x200.jpg" ,
 folder = True )
 if 84 - 84: oOOO00o000o - Oo / O0 - I1iIi1iIiiIiI
 plugintools . add_item (

 title = "Now Millenium 1992" ,
 url = "plugin://plugin.video.youtube/playlist/" + O00Ooo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41GGKRSTB1L._QL70_-200x200.jpg" ,
 folder = True )
 if 21 - 21: O0 * O0 % OoOOO00
 plugintools . add_item (

 title = "Now Millenium 1991" ,
 url = "plugin://plugin.video.youtube/playlist/" + OOOO0OOO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41PQ6HJNT3L-200x200.jpg" ,
 folder = True )
 if 94 - 94: oOOO00o000o + OoOoOO00 % i11iIiiIii
 plugintools . add_item (

 title = "Now Millenium 1990" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1i1ii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41J9FBM9M1L-200x200.jpg" ,
 folder = True )
 if 8 - 8: oo00ooOoO00 * O0
 plugintools . add_item (

 title = "Now Millenium 1989" ,
 url = "plugin://plugin.video.youtube/playlist/" + iII1ii1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41PWKBWYQDL-200x200.jpg" ,
 folder = True )
 if 73 - 73: OOO0o / II1111ii / oOOO00o000o / Ooo00oOo00o
 plugintools . add_item (

 title = "Now Millenium 1988" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1i1iiiI1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41QH0MG2E3L-200x200.jpg" ,
 folder = True )
 if 11 - 11: I1IiI + OOo0ii11I1 - OoooooooOO / Ooo00oOo00o
 plugintools . add_item (

 title = "Now Millenium 1987" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIIi + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41TDXR3PG5L-200x200.jpg" ,
 folder = True )
 if 34 - 34: oo00ooOoO00
 plugintools . add_item (

 title = "Now Millenium 1986" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO0o00oo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/4199SRAG7ZL-1-200x200.jpg" ,
 folder = True )
 if 45 - 45: oo00ooOoO00 / Oo / o0o00o0O00
 plugintools . add_item (

 title = "Now Millenium 1985" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1IIII + "/" ,
 thumbnail = "https://images-na.ssl-images-amazon.com/images/I/41TNYNJEQ1L.jpg" ,
 folder = True )
 if 44 - 44: OoOOO00 - o0o00o0O00 / OoOoOO00 * Ooo00oOo00o * Oo
 plugintools . add_item (

 title = "Now Millenium 1984" ,
 url = "plugin://plugin.video.youtube/playlist/" + oO00oOooooo0 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/4108960ER2L-200x200.jpg" ,
 folder = True )
 if 73 - 73: OOO0o - OOOo0 * i1IIi / i11iIiiIii * iIIII1iIIii % OoOoOO00
 plugintools . add_item (

 title = "Now Millenium 1983" ,
 url = "plugin://plugin.video.youtube/playlist/" + oOo + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41KME67QX9L-200x200.jpg" ,
 folder = True )
 if 56 - 56: OoooooooOO * Oo . Oo . OoOOO00
 plugintools . add_item (

 title = "Now Millenium 1982" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0OOooOoO + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41D5FJJRQWL._QL70_-200x200.jpg" ,
 folder = True )
 if 24 - 24: Oo . oOOO00o000o * o0o00o0O00 % I11i1iIiIIIIIii / iIIII1iIIii
 plugintools . add_item (

 title = "Now Millenium 1981" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1II1I1Iii1 + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/41JH50YTFNL-200x200.jpg" ,
 folder = True )
 if 58 - 58: OOOo0 - OoOOO00 % O0 . OOOo0 % Ooo00oOo00o % OOo0ii11I1
 plugintools . add_item (

 title = "Now Millenium 1980" ,
 url = "plugin://plugin.video.youtube/playlist/" + iiI11Iii + "/" ,
 thumbnail = "http://cdn.smehost.net/nowmusiccom-ukprod/wp-content/uploads/2016/10/4116KKBW01L-200x200.jpg" ,
 folder = True )
 if 87 - 87: II1111ii - i11iIiiIii
 plugintools . add_item (

 title = "Now Halloween" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1I1i + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DMBfRMTV4AAxtFy.jpg" ,
 folder = True )
 if 78 - 78: i11iIiiIii / iIii1I11I1II1 - OOO0o
 plugintools . add_item (

 title = "Now Housework" ,
 url = "plugin://plugin.video.youtube/playlist/" + I1IIIiIiIi + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DLnhhNBXUAE4fOa.jpg" ,
 folder = True )
 if 23 - 23: oOOO00o000o
 plugintools . add_item (

 title = "Now Sunday Mornings" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIIII1 + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DLCL0LaW0AES0a3.jpg" ,
 folder = True )
 if 40 - 40: OOO0o - OoOoOO00 / Oo
 plugintools . add_item (

 title = "Now Baking" ,
 url = "plugin://plugin.video.youtube/playlist/" + iIi1Ii1i1iI + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DMGy5l9XUAAJ3Fu.jpg" ,
 folder = True )
 if 14 - 14: OoOOO00
 plugintools . add_item (

 title = "Now Latino" ,
 url = "plugin://plugin.video.youtube/playlist/" + IIiI1 + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DKbkFx9WsAI1ZoC.jpg" ,
 folder = True )
 if 5 - 5: OOO0o . iIii1I11I1II1 % iIii1I11I1II1
 plugintools . add_item (

 title = "Now Top 20 Dance" ,
 url = "plugin://plugin.video.youtube/playlist/" + i1iI1 + "/" ,
 thumbnail = "https://scontent-lhr3-1.xx.fbcdn.net/v/t1.0-0/p200x200/21077785_10155643889381624_2707674874465510706_n.jpg?oh=faea49415109c25fbe2a1e1ddb71dd75&oe=5A3CDEE1" ,
 folder = True )
 if 56 - 56: OoooooooOO - oOOO00o000o - i1IIi
 plugintools . add_item (

 title = "Now Girls" ,
 url = "plugin://plugin.video.youtube/playlist/" + ii1I1IiiI1ii1i + "/" ,
 thumbnail = "https://pbs.twimg.com/media/DI5O-nXW4AAnuDH.jpg" ,
 folder = True )
 if 8 - 8: I1iIi1iIiiIiI / iIIII1iIIii . OOOo0 + OoOOO00 / i11iIiiIii
 plugintools . add_item (

 title = "Now Festivals" ,
 url = "plugin://plugin.video.youtube/playlist/" + O0o + "/" ,
 thumbnail = "https://scontent-lhr3-1.xx.fbcdn.net/v/t1.0-0/p200x200/20994234_10155643897126624_7245052529405352467_n.jpg?oh=c8f5c652eb4f81228dfc73c98e3eb111&oe=5A3B6468" ,
 folder = True )
 if 31 - 31: oo00ooOoO00 - iIii1I11I1II1 + I11i1iIiIIIIIii . Oo / OOo0ii11I1 % iIii1I11I1II1
 if 6 - 6: OOo0ii11I1 * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + OOO0o / i1IIi
oO0oo ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
